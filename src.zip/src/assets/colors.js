/* eslint-disable prettier/prettier */
const colors = {
  primaryColor: '#0ad48b',
  secondaryColor: '#13eba2',
  thirdColor: '#3bfeb8',
  backgroundColor: '#ffffff',
  homeButtonBgColor: '#e5e5e5',
  grey: '#979797'
};

export default colors;
