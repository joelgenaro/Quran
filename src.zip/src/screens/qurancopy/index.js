import React,{Component} from 'react';
import {View,Text} from 'react-native';

export default class QuranCopy extends Component {
    render(){
        return(
            <View>
                <Text>Hello</Text>
            </View>
        );
    }
};