/* eslint-disable prettier/prettier */
import Routes from './routes';

const App = Routes;

export default App;
