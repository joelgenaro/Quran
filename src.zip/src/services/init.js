export const hijriBase = 'api.aladhan.com/v1/'
export const quranBase = 'api.alquran.cloud/v1/'
export const quranID = 'quran.kemenag.go.id/index.php/api/v1/ayatweb/'